"""
AI package.
"""
